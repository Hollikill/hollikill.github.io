place a copy of HeartCore_datapack.zip into the datapacks folder in your world,
and place a copy of HeartCore_textures.zip in your resource packs folder and
enable it.

If you are using this on a server, make sure the resource-pack line in server.properties looks like:

resource-pack=https://hollikill.net/misc/HeartCore_textures.zip

Additionally, make sure HeartCore_datapack.zip is enabled by going in game on your server and typing:

/datapack enable "HeartCore_datapack.zip"